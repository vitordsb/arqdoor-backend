require("dotenv").config({ path: process.env.NODE_ENV === 'test' ? '.env.test' : '.env' });
const express = require("express");
const cors = require("cors");
const path = require("path");
const https = require("https");
const fs = require("fs");
const app = express();
const PORT = process.env.PORT || 8080;
const cookieParser = require("cookie-parser");
const helmet = require("helmet");

app.use(express.json());
app.use(cookieParser());
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" },
    contentSecurityPolicy: false,
  })
);

app.post("/webhook/deploy", (req, res) => {
  const token = req.headers["x-deploy-token"];

  if (!token || token !== process.env.DEPLOY_TOKEN) {
    return res.status(403).send("Forbidden");
  }

  exec("/var/www/arqdoor-backend/deploy.sh", (error, stdout, stderr) => {
    if (error) {
      console.error("Deploy error:", error);
      console.error(stderr);
      return res.status(500).send("Deploy failed");
    }

    console.log(stdout);
    if (stderr) console.error(stderr);
    return res.send("Deploy OK");
  });
});


const valENV = require("./utils/valEnv");
const sequelize = require("./database/config");
const router = require("./routers/router");
const { swaggerUi, swaggerSpec } = require("../swagger");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

const defaultCorsOrigins = [
  "http://localhost:5173",
  "http://127.0.0.1:5173",
  "http://localhost:3000",
  "http://localhost",
  "https://arqdoor-app.vercel.app",
  "https://arqdoor.com",
  "https://www.arqdoor.com",
];
const envCorsOrigins = (process.env.CORS_ORIGINS || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
const allowedCorsOrigins = [...new Set([...defaultCorsOrigins, ...envCorsOrigins])];
const allowAllCors = process.env.CORS_ALLOW_ALL === "true" || allowedCorsOrigins.includes("*");
const allowSubdomains = process.env.CORS_ALLOW_SUBDOMAINS === "true";
const corsBaseDomain = (process.env.CORS_BASE_DOMAIN || "").trim();

const isOriginAllowed = (origin) => {
  if (!origin) return true;
  if (allowAllCors) return true;
  if (allowedCorsOrigins.includes(origin)) return true;
  if (allowSubdomains && corsBaseDomain) {
    try {
      const hostname = new URL(origin).hostname;
      if (hostname === corsBaseDomain || hostname.endsWith(`.${corsBaseDomain}`)) {
        return true;
      }
    } catch {
      return false;
    }
  }
  return false;
};

app.use(
  cors({
    origin: (origin, callback) => {
      if (isOriginAllowed(origin)) {
        return callback(null, true);
      }
      return callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
  })
);


const raizDoProjeto = path.join(__dirname, "..");
const uploadsDir = path.join(raizDoProjeto, "uploads");
console.log("[uploads] raizDoProjeto =", raizDoProjeto);
console.log("[uploads] uploadsDir    =", uploadsDir);

try {
  require("fs").accessSync(uploadsDir);
} catch {
  console.warn("[uploads] pasta não encontrada:", uploadsDir);
}

app.use("/uploads", (req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // ou restrinja aos hosts acima
  next();
});

app.use(
  "/uploads",
  express.static(path.join(raizDoProjeto, "uploads"), {
    setHeaders(res, filePath) {
      res.setHeader("Access-Control-Allow-Origin", "*");
      if (filePath.endsWith(".pdf")) {
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader(
          "Content-Disposition",
          `inline; filename="${path.basename(filePath)}"`
        );
      }
    },
  })
);

app.use("/doc", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use(router);

// ===== MIDDLEWARE DE ERRO GLOBAL (deve ser o último) =====
const errorHandler = require("./middlewares/errorHandler");
app.use(errorHandler);

app.use("/", (req, res) => {
  res.message =
    "Essa não é uma rota válida, por favor verifique a documentação";
  setTimeout(() => {
    res.status(404).send(res.message);
  }, 1000);
});

const funcValidENV = async () => {
  const variableIsValid = await valENV();
  if (variableIsValid) {
    console.log(variableIsValid);
    process.exit(1);
  }
};
funcValidENV();

// [TEMP] Endpoint to fix DB schema issues remotely
app.get("/fix-db", async (req, res) => {
  try {
    const [results] = await sequelize.query("SHOW COLUMNS FROM User AND LIKE 'provider'");
    if (results.length === 0) {
      await sequelize.query("ALTER TABLE User ADD COLUMN provider ENUM('local', 'google') DEFAULT 'local'");
      return res.send("Column 'provider' added successfully.");
    }
    return res.send("Column 'provider' already exists.");
  } catch (error) {
    console.error("Fix DB Error:", error);
    // Ignore error if column exists (duplicate column name)
    if (error.original && error.original.code === 'ER_DUP_FIELDNAME') {
      return res.send("Column 'provider' already exists (caught error).");
    }
    return res.status(500).send("Error fixing DB: " + error.message);
  }
});

if (require.main === module) {
  sequelize
    .authenticate()
    .then(() => {
      console.log("Conexão com o banco estabelecida");

      // Inicializar todas as associações entre models
      require("./models/associations");

      // mantém o schema alinhado com os models sem precisar rodar migrações manuais
      // Evitamos alterações automáticas em produção para não criar índices duplicados (limite de 64 no MySQL)
      const enableSync = process.env.ENABLE_DB_SYNC === "true";
      const alterSync = process.env.ENABLE_DB_SYNC_ALTER === "true";
      if (!enableSync) {
        console.log("Sincronização automática desabilitada (ENABLE_DB_SYNC=false)");
        return null;
      }
      console.log(
        `Sincronizando modelos (alter=${alterSync ? "true" : "false"}) - use migrações para mudanças estruturais`
      );
      return sequelize.sync({ alter: alterSync }).catch((err) => {
        const fkDuplicate =
          err?.parent?.code === "ER_FK_DUP_NAME" ||
          err?.name === "SequelizeDatabaseError";
        if (fkDuplicate) {
          console.warn(
            "[sync] Detected duplicated FK constraint; skipping sync. Ajuste via migração/manual se necessário:",
            err?.parent?.sqlMessage || err?.message
          );
          return null;
        }
        throw err;
      });
    })
    .then(async () => {
      // garante que o usuário admin exista
      try {
        const adminEmail = process.env.ADMIN_EMAIL || "arqdoor@admin.com.br";
        const adminPassword = process.env.ADMIN_PASSWORD || "6aseqcx13zerq513";
        const existing = await User.findOne({ where: { email: adminEmail } });
        if (!existing) {
          const hashed = bcrypt.hashSync(adminPassword, 10);
          await User.create({
            name: "ArqDoor ADM",
            email: adminEmail,
            password: hashed,
            birth: new Date("1990-01-01"),
            gender: "Prefiro não dizer",
            type: "contratante",
            termos_aceitos: true,
            perfil_completo: true,
            is_email_verified: true,
          });
          console.log("[admin] Usuário admin criado");
        } else {
          console.log("[admin] Usuário admin já existe");
        }
      } catch (e) {
        console.warn("[admin] Falha ao garantir usuário admin:", e?.message || e);
      }

      app.listen(PORT, () => {
        console.log("==========================================");
        console.log(`Servidor rodando na porta ${PORT}`);
        console.log("==========================================");
      });

      const sslCertPath = "src/SSL/code.crt";
      const sslKeyPath = "src/SSL/code.key";

      if (fs.existsSync(sslCertPath) && fs.existsSync(sslKeyPath)) {
        https
          .createServer(
            {
              cert: fs.readFileSync(sslCertPath),
              key: fs.readFileSync(sslKeyPath),
            },
            app
          )
          .listen(8081, () => console.log("Servidor Rodando em Https (8081)"));
      } else {
        console.log("Certificados SSL não encontrados. Servidor HTTPS não iniciado.");
      }
    })
    .catch((error) => {
      console.error("Erro na conexão ou sincronização:", error);
    });
}

module.exports = app;
